package com.rest;

public class DigestScheme {

	 
	private final String realm;
	 private final String qop;
     private final String nonce;
     private final  String opaque;
   
     public DigestScheme(String realm, String qop, String nonce, String opaque) {
 		super();
 		this.realm = realm;
 		this.qop = qop;
 		this.nonce = nonce;
 		this.opaque = opaque;
 	}

     public String getQop() {
		return qop;
	}

	public String getNonce() {
         return nonce;
     }

     public String getRealm() {
         return realm;
     }

     public String getOpaque() {
         return opaque;
     }

   
     

     
	
}
