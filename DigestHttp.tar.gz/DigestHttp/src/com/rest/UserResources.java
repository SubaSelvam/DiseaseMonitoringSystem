package com.rest;

import java.io.IOException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;
import java.math.BigInteger;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.message.MessageUtils;

import sun.misc.BASE64Decoder;

@Path("/users")
public class UserResources {
	DigestScheme ds;
	List<User> ulist;
	 UserDAO ud=new UserDAO();
	@GET
	@Path("/user")
	 @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public List<User> verify(@HeaderParam("authorization") String authString) throws SQLException, NoSuchAlgorithmException
	{
		System.out.println(authString);
		String[] authParts = authString.split(",");
		String res=authParts[4];
		
		
            String   ha1 = getMd5("123:dcd98b7102dd2f0e8b11d0f600bfb0c093");
            System.out.println(ha1);
		    String ha2=getMd5("GET:/DigestHttp/rest/users/user");
		    System.out.println(ha2);
		    StringBuilder sd=new StringBuilder();
		    sd.append(ha1);
		    sd.append(":");
		    sd.append("dcd98b7102dd2f0e8b11d0f600bfb0c093");
		    sd.append(ha2);
		    String response=sd.toString();
		    System.out.println("server:"+response);
		//String HA1 = MD5(user:realm:password);
		 ulist=ud.getAllUsers();
         return ulist;
	}
	
	
	@GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public Response getNonce(@Context HttpHeaders header, @Context HttpServletResponse response,@HeaderParam("authorization") String authString) throws SQLException{
		
	   // String nonce = "dcd98b7102dd2f0e8b11d0f600bfb0c093";
	    //String realm="userDatabase";
	    //String qop="auth,auth-int";
       // String opaque="5ccc069c403ebaf9f0171e9517f40e41";
		System.out.println(authString);
	   String res="nonce = \"dcd98b7102dd2f0e8b11d0f600bfb0c093\",realm=\"userDatabase\",qop=\"auth,auth-int\",String opaque=\"5ccc069c403ebaf9f0171e9517f40e41\"";
	   Response respon = Response.status(200).
               header("DigestHeader", "nonce:dcd98b7102dd2f0e8b11d0f600bfb0c093;  realm:userDatabase;  qop:auth,auth-in;  opaque:5ccc069c403ebaf9f0171e9517f40e41").build();
	   //response.setHeader("Digest Header", res);
	   return respon;
    }
	 public static String getMd5(String input) throws NoSuchAlgorithmException 
	    { 
	        
		
	  
	            // Static getInstance method is called with hashing MD5 
	            MessageDigest md = MessageDigest.getInstance("MD5"); 
	  
	            // digest() method is called to calculate message digest 
	            //  of an input digest() return array of byte 
	            byte[] messageDigest = md.digest(input.getBytes()); 
	  
	            // Convert byte array into signum representation 
	            BigInteger no = new BigInteger(1, messageDigest); 
	  
	            // Convert message digest into hex value 
	            String hashtext = no.toString(16); 
	            while (hashtext.length() < 32) { 
	         
	                    return hashtext;
                 }
				return hashtext;
          }
}