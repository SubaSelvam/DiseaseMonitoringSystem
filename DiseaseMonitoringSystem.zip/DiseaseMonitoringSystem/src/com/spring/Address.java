package com.spring;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Address")
public class Address {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
    private Integer addressId;
	

	@Column(name = "area")
     private String area;
	
	
	@Column(name = "city")
    private String city;
	

	@Column(name = "pincode")
	private Integer pinCode;
    public Address() {}
	public Address(Integer addressId, String area, String city, Integer pinCode) {
		super();
		this.addressId = addressId;
		this.area = area;
		this.city = city;
		this.pinCode = pinCode;
	}
	
	public Address(String area, String city, Integer pinCode) {
		super();
		this.area = area;
		this.city = city;
		this.pinCode = pinCode;
	}

	public Integer getAddressId() {
		return addressId;
	}
	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getPinCode() {
		return pinCode;
	}
	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}
	
     
}
