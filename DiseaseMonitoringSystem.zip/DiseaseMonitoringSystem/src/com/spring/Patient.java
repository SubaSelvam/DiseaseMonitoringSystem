package com.spring;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name = "patient")
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@NotEmpty
	@NotNull
	@Pattern(regexp="[^0-9]+")
	@Size(min=6,max=20)
	@Column(name = "name")
	private String name;
	
	@NotEmpty
	@Column(name = "age")
	private Integer age;
	
	@NotEmpty
	@Column(name = "date")
	private Date date;
	
	@Autowired
	private Address address;
	
	@Autowired
	private  Disease disease;
	
	@NotEmpty
	@Column(name = "amount")
	private float amount;
	
	public Patient(String name, Integer age, Date date, Address address, Disease disease, float amount) {
		super();
		this.name = name;
		this.age = age;
		this.date = date;
		this.address = address;
		this.disease = disease;
		this.amount=amount;
	}
	public Patient(Integer id, String name, Integer age, Date date, Address address, Disease disease) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.date = date;
		this.address = address;
		this.disease = disease;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Autowired
	public Address getAddress() {
		return address;
	}
	@Autowired
	public void setAddress(Address address) {
		this.address = address;
	}
	@Autowired
	public Disease getDisease() {
		return disease;
	}
	@Autowired
	public void setDisease(Disease disease) {
		this.disease = disease;
	}
	  
	
	
}
