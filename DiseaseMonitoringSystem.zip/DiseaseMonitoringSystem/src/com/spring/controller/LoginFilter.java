package com.spring.controller;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.spring.User;
import com.spring.service.UserService;

//import dao.StageEventDAO;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.*;

@WebFilter(filterName = "LoginFilter", urlPatterns = {"/DiseaseMonitoringSystem/index"})
public class LoginFilter implements Filter {
    
    private static final boolean debug = true;

    // The filter configuration object we are associated with.  If
    // this value is null, this filter instance is not currently
    // configured. 
    private FilterConfig filterConfig = null;
    
    public LoginFilter() {
    }    
    @Autowired
    UserService userService;
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain)
            throws IOException, ServletException { 
         PrintWriter out =((HttpServletResponse) response).getWriter(); 
         String email=request.getParameter("email"); 
         String password="password";
         User u=userService.loginCheck(email,password);
        
        
         try
         {
                 if(u.getRole()=="hospital"){ 
                   
                           //out.println("if");
                      chain.doFilter(request, response);//sends request to next resource  
                }  
                else{  
                    //out.println("else");
                  RequestDispatcher rd=request.getRequestDispatcher("/DiseaseMonitoringSystem/home");  
                   rd.forward(request, response);  
                } 
         }
         catch(Exception e)
         {
             e.printStackTrace(out);
         }
        
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }
    
}

