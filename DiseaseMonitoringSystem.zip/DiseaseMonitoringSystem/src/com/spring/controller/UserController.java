package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.User;
import com.spring.Address;
import com.spring.Hospital;
import com.spring.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@RequestMapping("/signup")
	public String signUp() {
		return "signup";
	}
	
	@RequestMapping("/login")
	public String login() {
		return "login";
	}
	
	@RequestMapping("/display")
	public String display() {
		return "display";
	}
	@RequestMapping("/index")
	public String index() {
		return "index";
	}
	@RequestMapping("/register")
	public String register() {
		return "register";
	}
	
	@RequestMapping("/home")
	public String home() {
		return "home";
	}
	
	
	@RequestMapping("/saveProcess")
	public ModelAndView saveUser(@RequestParam("userName")String name,@RequestParam("password")String password,@RequestParam("email")String email,@RequestParam("area")String address,@RequestParam("role")String role) {
	//	Integer m = Integer.parseInt(mobile);
		String[] strarr=address.split(",");
     Address address1=new Address(strarr[0],strarr[1],Integer.parseInt(strarr[2]));;
     /*List<Address> alist=userService.getAddressByCity(strarr[1]);
     int flag=0;
   /  for(Address temp:alist)
     {
    	 if(temp.getArea().equals(strarr[0])||temp.getPinCode().equals(strarr[2]))
    			 {
    		        address1=new Address(temp.getAddressId(),temp.getArea(),temp.getCity(),temp.getPinCode());
    		        flag=1;
    			 }
     }
     if(flag==0)
     {
    	
    		 address1=new Address(strarr[0],strarr[1],Integer.parseInt(strarr[2]));
     }*/
     
     User user = new User(name,password,email,address1,role);
     userService.saveUserObj(user);
	
	   if(user.getRole().equals("hospital"))
		   return new ModelAndView("register","user",user);
	   else
	   {
		   
		   return new ModelAndView("home");
	   }
	}
	
	@RequestMapping("/saveHospital")
	public String saveHospital(@RequestParam("hospitalName")String name,@RequestParam("mobile")String mobile,@RequestParam("email")String email,@RequestParam("address")String address,@RequestParam("user")String userEmail) {
	//	Integer m = Integer.parseInt(mobile);
		String[] strarr=address.split(",");
     Address address1=new Address(strarr[0],strarr[1],Integer.parseInt(strarr[2]));
    User user=userService.getUserByEmail(userEmail);
     Hospital hospital = new Hospital(name,mobile,email,address1,user);
	  userService.saveHospital(hospital);
     return "index";
	}
	
	@RequestMapping("/loginCheck")
	public ModelAndView check(@RequestParam("email")String email,@RequestParam("password")String password) {
		
		User u=userService.loginCheck(email,password);
		//Hospital h=userService.getHospitalByUser(u);
		if(u==null)
		{
			return new ModelAndView("login");
		}
		else if(u.getPassword().equals(password))
		{
			if(u.getRole().equals("hospital"))
				return new ModelAndView("index");
			else
				return new ModelAndView("home");
		}
		else
			return new ModelAndView("login");
	}
/*	@RequestMapping("/addPatient")
	public String addPatient(@RequestParam("userName")String name,@RequestParam("password")String password,@RequestParam("mobile")Integer mobile,@RequestParam("email") String email,@RequestParam("area") String area,@RequestParam("city") String city,@RequestParam("pinCode") Integer pinCode) {
		Address address=new Address(area,city,pinCode);
		User user = new User(name,password,mobile,email,address);
		userService.saveUserObj(user);
		return "redirect:login.do";
	}*/
	
}
