package com.spring;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.ForeignKey;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name="Hospital")
public class Hospital {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "hospitalName")
	 private String hospitalName;
	

	@Column(name = "mobile")
	private String mobile;
	

	public String getMobile() {
		return mobile;
	}



	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	@Column(name = "email")
    private String email;
	
	@ManyToOne
	@ForeignKey(name="address")
	@Autowired
	private Address address;
	
	

	@ManyToOne
	@ForeignKey(name="user")
	@Autowired
	private User user;
	
	public Hospital() {}
	
	
	
public Hospital(Integer id, String hospitalName, String mobile, String email, Address address) {
		super();
		this.id = id;
		this.hospitalName = hospitalName;
		
		this.mobile = mobile;
		this.email = email;
		this.address = address;
		
	}

public Hospital(String hospitalName, String mobile,  String email, Address address) {
	super();
	this.hospitalName = hospitalName;
	//this.password = password;
     this.mobile = mobile;
	this.email = email;
	this.address = address;
	
}


public Hospital(String hospitalName, String mobile,  String email, Address address,User user) {
	super();
	this.hospitalName = hospitalName;
	//this.password = password;
     this.mobile = mobile;
	this.email = email;
	this.address = address;
	this.user=user;
	
}


public User getUser() {
	return user;
}



public void setUser(User user) {
	this.user = user;
}



public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getHospitalName() {
	return hospitalName;
}
public void setUserName(String hospitalName) {
	this.hospitalName = hospitalName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}

   
}
 