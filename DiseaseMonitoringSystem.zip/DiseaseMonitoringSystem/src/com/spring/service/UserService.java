package com.spring.service;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.Address;
import com.spring.Hospital;
import com.spring.User;



@Service
public class UserService {

	@Autowired
	 public SessionFactory sessionFactory;
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	 }
	
	@Autowired
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

    @Transactional
	public void saveUserObj(User userObj) {
    	Address address=userObj.getAddress();
    	sessionFactory.getCurrentSession().save(address);
		sessionFactory.getCurrentSession().save(userObj);
	}
    
    @Transactional
	public void saveHospital(Hospital hospital) {
    	Address address=hospital.getAddress();
    	//User user=hospital.getUser();
    	sessionFactory.getCurrentSession().save(address);
    	//sessionFactory.getCurrentSession().save(user);
		sessionFactory.getCurrentSession().save(hospital);
	}
	
	@SuppressWarnings("unchecked")
	public List<User> getAllUser() {
		Session currentSession = sessionFactory.getCurrentSession();
		List<User> theQuery = currentSession.createQuery("from User").list();
		return theQuery;
	}
	
	@Transactional
	public User loginCheck(String email,String password)
	{
	return (User)sessionFactory.getCurrentSession().createQuery("from User U where U.email=:email ").setString("email",email).uniqueResult();
	}	
	
	@Transactional
	public User getUserByEmail(String email)
	{
	return (User)sessionFactory.getCurrentSession().createQuery("from User U where U.email=:email ").setString("email",email).uniqueResult();
	}
	
	@Transactional
	public List<Address> getAddressByCity(String city)
	{
	@SuppressWarnings("unchecked")
	List<Address> alist=(List<Address>)sessionFactory.getCurrentSession().createQuery("from Address a where a.city=:city ").list();
	return alist;
	}
	
}
